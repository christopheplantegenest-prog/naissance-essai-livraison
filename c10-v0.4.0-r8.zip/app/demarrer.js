import { VERSION } from './version.js';
document.querySelector('[data-version]').textContent = VERSION;
document.documentElement.dataset.demarrage = 'ok';
// v0.4.0 (R8)
