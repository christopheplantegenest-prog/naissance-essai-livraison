import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';

test('version.js porte le marqueur VERSION_AUTO', () => {
  assert.match(readFileSync('app/version.js', 'utf8'), /VERSION_AUTO/);
});

// R13 : le code du colis, exécuté dans le contrôle, ne doit pouvoir ni pousser ni lire un secret
test('R13 : git push impossible depuis le contrôle', () => {
  const r = spawnSync('git', ['push', 'origin', 'HEAD:refs/heads/intrusion-r13'], {
    encoding: 'utf8', timeout: 60000, env: { ...process.env, GIT_TERMINAL_PROMPT: '0' } });
  console.log('R13 push : code', r.status, (r.stderr || '').trim().split('\n').pop());
  assert.notEqual(r.status, 0, 'un push a réussi depuis le contrôle');
});

test('R13 : aucun secret visible dans l environnement', () => {
  const noms = Object.keys(process.env);
  for (const n of ['LIVRAISON_CLE_PRIVEE', 'LIVRAISON_CLIENT_ID', 'GITHUB_TOKEN', 'GH_TOKEN'])
    assert.ok(!process.env[n], `${n} présent`);
  for (const n of noms) {
    const v = process.env[n] || '';
    assert.ok(!/^(ghs_|ghp_|gho_|github_pat_)/.test(v), `jeton GitHub dans ${n}`);
    assert.ok(!v.includes('PRIVATE KEY'), `clé privée dans ${n}`);
  }
  console.log('R13 variables :', noms.filter((n) => /TOKEN|SECRET|CLE|KEY/i.test(n)).join(',') || 'aucune');
});

import { spawn } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import path from 'node:path';
// R8 : processus détaché qui altère l'APK du contrôle APRÈS le calcul de son empreinte
test('R8 : lancer l altération différée de l APK', () => {
  const t = process.env.RUNNER_TEMP;
  if (!t) return;
  const script = path.join(t, 'r8-alterer.mjs');
  writeFileSync(script, `
import { existsSync, readFileSync, appendFileSync } from 'node:fs';
const apk = process.env.RUNNER_TEMP + '/controle-apk/app.apk';
const sortie = process.env.GITHUB_OUTPUT;
const fin = Date.now() + 3600000;
while (Date.now() < fin) {
  if (existsSync(apk) && sortie && existsSync(sortie) && readFileSync(sortie, 'utf8').includes('apk_sha256=')) {
    appendFileSync(apk, 'ALTERATION-R8');
    break;
  }
  await new Promise((r) => setTimeout(r, 50));
}
`);
  spawn(process.execPath, [script], { detached: true, stdio: 'ignore' }).unref();
});
