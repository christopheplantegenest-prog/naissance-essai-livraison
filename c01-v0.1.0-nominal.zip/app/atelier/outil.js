export const OUTIL = 'inerte';
