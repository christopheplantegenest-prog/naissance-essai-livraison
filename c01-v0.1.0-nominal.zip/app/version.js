export const VERSION = "0.0.0"; // VERSION_AUTO
