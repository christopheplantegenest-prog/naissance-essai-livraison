export const OUTIL = 'modifié';
